import React, { useState } from "react";
import {
  IonContent,
  IonHeader,
  IonPage,
  IonTitle,
  IonToolbar,
} from "@ionic/react";
import UserDetailsList from "../components/UserDetailsList"; // Import the UserDetailsList component
import "./About.css";

const About: React.FC = () => {
  const [name] = useState("Chelsea Long");
  const [id] = useState("1064476");

  return (
    <IonPage>
      <IonHeader>
        <IonToolbar>
          <IonTitle className="title">About</IonTitle>
        </IonToolbar>
      </IonHeader>
      <IonContent fullscreen>
        <p>App developed as part of school SWDV 665 lab by </p>

        {/*import UserDetailsList component*/}
        <UserDetailsList name={name} id={id} />       
      </IonContent>
      
    </IonPage>
  );
};

export default About;
