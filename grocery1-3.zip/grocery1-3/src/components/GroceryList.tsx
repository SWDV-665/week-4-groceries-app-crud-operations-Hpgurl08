import React, { useRef } from "react";
import {
  IonList,
  IonItem,
  IonLabel,
  IonButton,
  IonIcon,
  IonItemSliding,
  IonItemOptions,
  IonItemOption,
} from "@ionic/react";
import { trashBinOutline } from "ionicons/icons";
import { createOutline } from "ionicons/icons";

interface GroceryItem {
  name: string;
  quantity: string;
}

interface GroceryListProps {
  groceryItems: GroceryItem[];
  removeItemFromList: (index: number) => void;
  editItem: (index: number) => void; // Add editItem prop
}

const GroceryList: React.FC<GroceryListProps> = ({
  groceryItems,
  removeItemFromList,
  editItem,
}) => {
  const listRef = useRef<HTMLIonListElement | null>(null);

  const closeSlidingItems = () => {
    if (listRef.current) {
      listRef.current.closeSlidingItems();
    }
  };

  const handleSwipe = (index: number) => {
    removeItemFromList(index);
    closeSlidingItems();
  };

  return (
    <IonList ref={listRef}>
      <IonItem>
        <IonLabel className="item">Name</IonLabel>
        <IonLabel className="item">Quantity</IonLabel>
      </IonItem>

      {groceryItems.length === 0 ? (
        <IonItem>
          <IonLabel>No items in the list</IonLabel>
        </IonItem>
      ) : (
        // Below the Delete functionality, Added an edit functionality
        groceryItems.map((item: GroceryItem, index: number) => (
          <IonItemSliding key={index} className="listItem">
            <IonItem>
              <IonLabel className="item">{item.name} </IonLabel>
              <IonLabel className="item">({item.quantity})</IonLabel>
            </IonItem>
            <IonItemOptions side="end">
              <IonItemOption
                className="delete"
                color="danger"
                onClick={() => handleSwipe(index)}
              >
                <IonIcon icon={trashBinOutline} /> 
              </IonItemOption>
              <IonItemOption
                className="edit" // assigned edit name
                color="success" // assigned diffrent color
                onClick={() => editItem(index)} // called
              > 
                <IonIcon icon={createOutline} /> 
              </IonItemOption>
            </IonItemOptions>
          </IonItemSliding>
        ))
      )}
    </IonList>
  );
};

export default GroceryList;
